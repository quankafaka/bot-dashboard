import { useMemo, useState } from 'react'
import { money, pct, tone, betTime, multiAccount } from '../lib/format'
import { useOdds } from '../lib/odds'
import AlertCell, { LimitCell, hasLimits } from './AlertCell'
import BetCard from './BetCard'
import { useIsMobile } from '../lib/useIsMobile'
import { betLabel, SOURCE_LABEL } from '../lib/metrics'

const PAGE = 100
const RESULT_LABEL = {
  WIN: 'Won', LOSS: 'Lost', HALF_WIN: 'Half won', HALF_LOSS: 'Half lost', PUSH: 'Push', VOID: 'Void',
}

export default function Graded({ rows, currency, accountNames }) {
  const [q, setQ] = useState('')
  const fmt = useOdds()
  const [shown, setShown] = useState(PAGE)
  const mobile = useIsMobile()

  const showLimit = hasLimits(rows)
  const showAccount = multiAccount(rows)
  const graded = useMemo(() => {
    const needle = q.trim().toLowerCase()
    return rows
      .filter((r) => r.status === 'graded')
      .filter((r) => !needle || `${r.home_team} ${r.away_team} ${r.league} ${r.selection}`.toLowerCase().includes(needle))
      .sort((a, b) => b.placedMs - a.placedMs)
  }, [rows, q])

  return (
    <section>
      <div className="search">
        <label htmlFor="q">Find a bet</label>
        <input id="q" type="search" placeholder="Team, league or selection" value={q}
          onChange={(e) => { setQ(e.target.value); setShown(PAGE) }} />
        <span className="muted">{graded.length.toLocaleString('en-CA')} settled</span>
      </div>
      {mobile ? (
        <div className="cards-list">
          {graded.slice(0, shown).map((r) => (
            <BetCard key={r.wager_id} r={r} currency={currency} accountNames={accountNames}
              showAccount={showAccount} mode="graded" />
          ))}
          {graded.length === 0 && <p className="muted">No settled bets match “{q}”.</p>}
        </div>
      ) : (
      <div className="scroll">
        <table>
          <thead>
            <tr>
              <th scope="col">Placed</th>
              <th scope="col">Game</th>
              <th scope="col">Bet</th>
              <th scope="col">Alert / model</th>
              {showLimit && <th scope="col" className="num">Pinnacle limit</th>}
              <th scope="col" className="num">Odds</th>
              <th scope="col" className="num">Stake</th>
              <th scope="col" className="num">CLV</th>
              <th scope="col">Result</th>
              <th scope="col" className="num">Profit</th>
              {showAccount && <th scope="col">Account</th>}
            </tr>
          </thead>
          <tbody>
            {graded.slice(0, shown).map((r) => (
              <tr key={r.wager_id}>
                <td className="nowrap">{betTime(r)}</td>
                <td>
                  <div>{r.home_team} v {r.away_team}</div>
                  <div className="sub">
                    {r.league}{r.home_score != null && `, ended ${r.home_score}–${r.away_score}`}
                  </div>
                </td>
                <td>
                  <div>{r.selection}</div>
                  <div className="sub">
                    {betLabel(r)}
                    {r.source !== 'bot' && <span className="tag">{SOURCE_LABEL[r.source] ?? r.source}</span>}
                    {r.is_freebet && <span className="tag">Free bet</span>}
                  </div>
                </td>
                <AlertCell r={r} />
                {showLimit && <LimitCell r={r} />}
                <td className="num">
                  {fmt(r.price_filled)}
                  {r.closing_price != null && <div className="sub">closed {fmt(r.closing_price)}</div>}
                </td>
                <td className="num">{money(r.stake, currency)}</td>
                <td className={`num ${tone(r.clv_pct)}`}>{pct(r.clv_pct)}</td>
                <td><span className={`result r-${r.result?.toLowerCase()}`}>{RESULT_LABEL[r.result] ?? r.result}</span></td>
                <td className={`num ${tone(r.profit)}`}>{money(r.profit, currency, { sign: true })}</td>
                {showAccount && <td>{accountNames[r.account] ?? r.account}</td>}
              </tr>
            ))}
            {graded.length === 0 && (
              <tr><td colSpan={9 + (showLimit ? 1 : 0) + (showAccount ? 1 : 0)} className="muted">No settled bets match “{q}”.</td></tr>
            )}
          </tbody>
        </table>
      </div>
      )}
      {graded.length > shown && (
        <button className="more" onClick={() => setShown((n) => n + PAGE)}>
          Show {Math.min(PAGE, graded.length - shown)} more
        </button>
      )}
    </section>
  )
}
